#include <stdio.h>
#include <math.h>

#define MAX_VERTICES 100

typedef struct {
    double x, y;
} Point;

typedef struct {
    Point p1, p2;
} Line;

typedef struct {
    Point vertices[MAX_VERTICES];
    int num_vertices;
} Polygon;

void print_point(Point p) {
    printf("(%.2f, %.2f)", p.x, p.y);
}

void print_polygon(Polygon poly) {
    printf("Polygon with %d vertices:\n", poly.num_vertices);
    for (int i = 0; i < poly.num_vertices; ++i) {
        print_point(poly.vertices[i]);
        printf("\n");
    }
}

Point subtract(Point a, Point b) {
    return (Point){a.x - b.x, a.y - b.y};
}

Point add(Point a, Point b) {
    return (Point){a.x + b.x, a.y + b.y};
}

Point normalize(Point p) {
    double length = sqrt(p.x * p.x + p.y * p.y);
    return (Point){p.x / length, p.y / length};
}

Point perpendicular(Point p) {
    return (Point){-p.y, p.x};
}

Point scale(Point p, double factor) {
    return (Point){p.x * factor, p.y * factor};
}

Polygon expand_polygon(Polygon input, double width) {
    Polygon expanded;
    expanded.num_vertices = 0;

    for (int i = 0; i < input.num_vertices; ++i) {
        Point current = input.vertices[i];
        Point next = input.vertices[(i + 1) % input.num_vertices];

        Point edge = subtract(next, current);
        Point normal = perpendicular(edge);
        normal = normalize(normal);
        normal = scale(normal, width);

        Point offset1 = add(current, normal);
        Point offset2 = add(next, normal);

        expanded.vertices[expanded.num_vertices++] = offset1;
        expanded.vertices[expanded.num_vertices++] = offset2;
    }

    return expanded;
}

int main() {
    Polygon polygon = {
        .vertices = {{0, 0}, {0, 5}, {5, 5}, {5, 0}},
        .num_vertices = 4
    };

    double width = 1.0; // 扩展宽度

    printf("Original Polygon:\n");
    print_polygon(polygon);

    Polygon expanded = expand_polygon(polygon, width);

    printf("\nExpanded Polygon:\n");
    print_polygon(expanded);

    return 0;
}

