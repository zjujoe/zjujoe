﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace CakeCutting
{
    public partial class Form1 : Form
    {
        private List<Line> lines = new List<Line>();
        private List<PointF[]> polygons = new List<PointF[]>();
        private List<Color> polygonColors = new List<Color>();  // 保存每个多边形的颜色
        private const int squareSize = 200; // 正方形的边长
        private Random rand = new Random();
        private PointF offset = new PointF(300, 200); // 正方形和直线的偏移量
        //private PointF offset = new PointF(0, 0); // 正方形和直线的偏移量

        public Form1()
        {
            InitializeComponent();

            // 设置窗口初始大小为 800x800
            this.Size = new Size(800, 600);

            //横竖切
            lines.Add(new Line(new PointF(100 + offset.X, -50 + offset.Y), new PointF(100 + offset.X, 250 + offset.Y)));
            lines.Add(new Line(new PointF(-50 + offset.X, 100 + offset.Y), new PointF(250 + offset.X, 100 + offset.Y)));
            lines.Add(new Line(new PointF(0 + offset.X, 50 + offset.Y), new PointF(200 + offset.X, 50 + offset.Y)));
            lines.Add(new Line(new PointF(0 + offset.X, 150 + offset.Y), new PointF(200 + offset.X, 150 + offset.Y)));
            lines.Add(new Line(new PointF(50 + offset.X, 0 + offset.Y), new PointF(50 + offset.X, 200 + offset.Y)));
            lines.Add(new Line(new PointF(150 + offset.X, 0 + offset.Y), new PointF(150 + offset.X, 200 + offset.Y)));

            //斜切
            lines.Add(new Line(new PointF(0 + offset.X, 0 + offset.Y), new PointF(200 + offset.X, 200 + offset.Y)));
            lines.Add(new Line(new PointF(0 + offset.X, 200 + offset.Y), new PointF(200 + offset.X, 0 + offset.Y)));
            lines.Add(new Line(new PointF(100 + offset.X, -50 + offset.Y), new PointF(250 + offset.X, 100 + offset.Y)));
            lines.Add(new Line(new PointF(100 + offset.X, 250 + offset.Y), new PointF(-50 + offset.X, 100 + offset.Y)));
            lines.Add(new Line(new PointF(100 + offset.X, 250 + offset.Y), new PointF(250 + offset.X, 100 + offset.Y)));
            lines.Add(new Line(new PointF(100 + offset.X, -50 + offset.Y), new PointF(-50 + offset.X, 100 + offset.Y)));
            
            
            // 初始化正方形
            PointF[] square = new PointF[]
            {
                new PointF(offset.X, offset.Y),
                new PointF(offset.X + squareSize, offset.Y),
                new PointF(offset.X + squareSize, offset.Y + squareSize),
                new PointF(offset.X, offset.Y + squareSize)
            };

            polygons.Add(square);  // 初始多边形为正方形
            polygonColors.Add(GetRandomColor());  // 初始化正方形的颜色

            // 使用直线逐次切割
            foreach (var line in lines)
            {
                List<PointF[]> newPolygons = new List<PointF[]>();
                List<Color> newColors = new List<Color>();  // 用于保存新生成多边形的颜色
                foreach (var polygon in polygons)
                {
                    var slicedPolygons = SlicePolygon(polygon, line);
                    newPolygons.AddRange(slicedPolygons);
                    foreach (var _ in slicedPolygons)
                    {
                        newColors.Add(GetRandomColor());  // 为新生成的多边形分配随机颜色
                    }
                }
                polygons = newPolygons;
                polygonColors = newColors;
            }
        }

        // 计算交点和多边形切割
        private List<PointF[]> SlicePolygon(PointF[] polygon, Line line)
        {
            List<PointF> intersections = new List<PointF>();
            Dictionary<PointF, Tuple<PointF, PointF>> intersectionInfo = new Dictionary<PointF, Tuple<PointF, PointF>>();

            // 找出多边形每一条边与直线的交点
            for (int i = 0; i < polygon.Length; i++)
            {
                int next = (i + 1) % polygon.Length;
                PointF? inter = GetIntersection(line.Start, line.End, polygon[i], polygon[next]);
                if (inter.HasValue)
                {
                    if (IsPointInList2(inter.Value, polygon))
                    {
                        if (IsPointEqual(inter.Value, polygon[next]))
                        {
                            continue;
                        }
                    }
                    // 如果交点已经存在于交点集合中，则跳过
                    if (!IsPointInList(inter.Value, intersections))
                    {
                        intersections.Add(inter.Value);
                        intersectionInfo[inter.Value] = Tuple.Create(polygon[i], polygon[next]);
                    }
                }
            }

            // 如果没有交点或只有一个交点，返回原多边形
            if (intersections.Count < 2)
            {
                return new List<PointF[]> { polygon };
            }

            // 根据交点创建两个新多边形
            PointF inter1 = intersections[0];
            PointF inter2 = intersections[1];

            PointF[] poly1 = CreatePolygon(polygon, inter1, inter2, intersectionInfo, true);
            PointF[] poly2 = CreatePolygon(polygon, inter1, inter2, intersectionInfo, false);

            return new List<PointF[]> { poly1, poly2 };
        }

        // 根据交点及其两侧的顶点信息生成多边形
        private PointF[] CreatePolygon(PointF[] polygon, PointF inter1, PointF inter2, Dictionary<PointF, Tuple<PointF, PointF>> intersectionInfo, bool startFromInter1)
        {
            List<PointF> newPolygon = new List<PointF>();
            PointF start = startFromInter1 ? inter1 : inter2;
            PointF end = startFromInter1 ? inter2 : inter1;

            // 获取交点的两侧顶点
            Tuple<PointF, PointF> startInfo = intersectionInfo[start];
            Tuple<PointF, PointF> endInfo = intersectionInfo[end];

            // 添加起始交点的两侧顶点
            newPolygon.Add(startInfo.Item1);
            PointF current = startInfo.Item1;
            if (!IsPointInList(start, newPolygon))
            {
                newPolygon.Add(start);
            }
            if (!IsPointInList(end, newPolygon))
            {
                newPolygon.Add(end);
            }
            if (!IsPointInList(endInfo.Item2, newPolygon))
            {
                newPolygon.Add(endInfo.Item2);
                current = endInfo.Item2;
            }
            // 从起始交点继续添加顶点
            if (!current.Equals(startInfo.Item1))
            {
                current = polygon[(Array.IndexOf(polygon, current) + 1) % polygon.Length];
            }
            while (!current.Equals(startInfo.Item1))
            {
                if (!IsPointInList(current, newPolygon))
                    newPolygon.Add(current);
                current = polygon[(Array.IndexOf(polygon, current) + 1) % polygon.Length];

            }

            return newPolygon.ToArray();
        }

        // 计算两条线段的交点
        private PointF? GetIntersection(PointF p1, PointF p2, PointF p3, PointF p4)
        {
            float A1 = p2.Y - p1.Y;
            float B1 = p1.X - p2.X;
            float C1 = A1 * p1.X + B1 * p1.Y;

            float A2 = p4.Y - p3.Y;
            float B2 = p3.X - p4.X;
            float C2 = A2 * p3.X + B2 * p3.Y;

            float det = A1 * B2 - A2 * B1;

            if (Math.Abs(det) < 1e-9)
            {
                return null; // 平行线，没有交点
            }
            else
            {
                float x = (B2 * C1 - B1 * C2) / det;
                float y = (A1 * C2 - A2 * C1) / det;

                // 检查交点是否在线段范围内
                if (IsOnSegment(p1, p2, new PointF(x, y)) && IsOnSegment(p3, p4, new PointF(x, y)))
                {
                    return new PointF(x, y);
                }

                return null;
            }
        }

        // 判断交点是否在线段内
        private bool IsOnSegment(PointF p1, PointF p2, PointF p)
        {
            return Math.Min(p1.X, p2.X) <= p.X && p.X <= Math.Max(p1.X, p2.X) &&
                   Math.Min(p1.Y, p2.Y) <= p.Y && p.Y <= Math.Max(p1.Y, p2.Y);
        }

        // 判断两个点是否相等（允许浮点误差）
        private bool IsPointEqual(PointF p1, PointF p2)
        {
            return Math.Abs(p1.X - p2.X) < 1e-6 && Math.Abs(p1.Y - p2.Y) < 1e-6;
        }

        // 判断点是否已经在集合中
        private bool IsPointInList(PointF point, List<PointF> points)
        {
            foreach (var p in points)
            {
                if (IsPointEqual(p, point))
                {
                    return true;
                }
            }
            return false;
        }
        // 判断点是否已经在集合中
        private bool IsPointInList2(PointF point, PointF[] points)
        {
            foreach (var p in points)
            {
                if (IsPointEqual(p, point))
                {
                    return true;
                }
            }
            return false;
        }
        // 随机生成颜色
        private Color GetRandomColor()
        {
            return Color.FromArgb(100, rand.Next(256), rand.Next(256), rand.Next(256));
        }

        // 重写 OnPaint 方法以图形化显示正方形、直线和多边形
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // 绘制正方形
            //Pen blackPen = new Pen(Color.Black, 2);
            Pen bluePen = new Pen(Color.Blue, 2);
            g.DrawRectangle(bluePen, offset.X, offset.Y, squareSize, squareSize);

            // 绘制直线
            Pen greenPen = new Pen(Color.Green, 2);
            foreach (var line in lines)
            {
                g.DrawLine(greenPen, line.Start, line.End);
            }

            // 绘制每个多边形，使用不同的颜色填充
            //Pen bluePen = new Pen(Color.Blue, 2);

            for (int i = 0; i < polygons.Count; i++)
            {
                Brush polygonBrush = new SolidBrush(polygonColors[i]);  // 获取对应的颜色
                g.FillPolygon(polygonBrush, polygons[i]); // 填充多边形
                //g.DrawPolygon(bluePen, polygons[i]); // 绘制多边形边框
            }

            base.OnPaint(e);
        }
    }

    // 定义直线结构体
    public struct Line
    {
        public PointF Start, End;

        public Line(PointF start, PointF end)
        {
            Start = start;
            End = end;
        }
    }
}
