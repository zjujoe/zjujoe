import os
import pygame
import sys
import random
import pygame.font

pygame.init()

cols = 10  # 游戏网格列数，可以调整，不要太小
rows = 20  # 游戏网格行数，可以调整
cell_size = 38  # 网格的大小
block_size = cell_size - 1  # 一个方块的大小,小于等于cell_size，即要有边距
block_edge = int(block_size / 2)  # 方块的立体感，数字>=1,数字越小立体感越强
fps = 38  # 每秒帧数，建议范围20-60，越大难度递进越越缓

win_width = cols * 2 * cell_size + 6 * cell_size
win_hight = (rows + 1) * cell_size
os.environ['SDL_VIDEO_CENTERED'] = '1'  # 设置pygame窗口居中，注意值的设置方式。必须在pg.display.set_mode前面调用
screen = pygame.display.set_mode((win_width, win_hight))
pygame.display.set_caption("我的双打俄罗斯方块")

blocks = {
    1: [[(0, 1), (1, 1), (2, 1), (3, 1)],
        [(2, 0), (2, 1), (2, 2), (2, 3)]],  # 条型
    2: [[(1, 1), (2, 1), (1, 2), (2, 2)]],  # 田字型
    3: [[(0, 1), (1, 1), (2, 1), (1, 2)],
        [(1, 0), (0, 1), (1, 1), (1, 2)],
        [(1, 1), (0, 2), (1, 2), (2, 2)],
        [(1, 0), (1, 1), (2, 1), (1, 2)]],  # T型
    4: [[(0, 1), (1, 1), (2, 1), (0, 2)],
        [(0, 0), (1, 0), (1, 1), (1, 2)],
        [(2, 1), (0, 2), (1, 2), (2, 2)],
        [(1, 0), (1, 1), (1, 2), (2, 2)]],  # L型
    5: [[(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (0, 2), (1, 2)],
        [(0, 1), (0, 2), (1, 2), (2, 2)],
        [(1, 0), (2, 0), (1, 1), (1, 2)]],  # J型
    6: [[(1, 1), (2, 1), (0, 2), (1, 2)],
        [(0, 0), (0, 1), (1, 1), (1, 2)]],  # S型
    7: [[(0, 1), (1, 1), (1, 2), (2, 2)],
        [(2, 0), (1, 1), (2, 1), (1, 2)]],  # Z型
}

app_colors = [(138, 200, 198), (200, 50, 50), (50, 200, 200), (50, 50, 200), (200, 200, 50), (200, 50, 200), (50, 200, 50), (125, 50, 125), (180, 180, 180)]

class Tetris():
    def __init__(self, x0, y0):
        self.x0, self.y0 = x0, y0
        self.rect = pygame.Rect(0, 0, block_size, block_size)
        self.display_arrs = [[0 for i in range(cols)] for j in range(rows)]
        self.color_arrs = [[0 for i in range(cols)] for j in range(rows)]
        self.x, self.y = 0, 0
        self.key = 0
        self.index = 0
        self.next_key = self.randkey_gen()
        self.speed = fps
        self.fall_buffer = self.speed
        self.fall_speed_up = False
        self.score = 0
        self.lines = 0
        self.level = 0
        self.opponent_rows = []
        self.game_over_flag = False
        self.creat_new_block()

    def creat_new_block(self):
        if not self.game_over_flag:
            self.key = self.next_key
            self.next_key = self.randkey_gen()
            self.index = 0
            self.x = 4
            self.y = -1
            if self.opponent_rows:
                self.add_opponent_rows()
            if self.check_game_over():
                self.game_over()

    def randkey_gen(self):
        keys = [1, 1, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 7, 7]
        return keys[random.randint(0, len(keys) - 1)]

    def move(self, dx, dy):
        if not self.game_over_flag and self.can_move(self.index, dx, dy):
            self.x += dx
            self.y += dy
        elif dy:
            if self.y <= 0:
                self.game_over()
            else:
                self.stop_move()

    def rotate(self):
        if not self.game_over_flag:
            next_index = (self.index + 1) % len(blocks[self.key])
            if self.can_move(next_index, 0, 0):
                self.index = next_index

    def can_move(self, index, dx, dy):
        for (x, y) in blocks[self.key][index]:
            col, row = self.x + x + dx, self.y + y + dy
            if col >= cols or col < 0 or row >= rows or row < 0:
                return False
            if self.display_arrs[row][col]:
                return False
        return True

    def stop_move(self):
        self.score += 3
        for (x, y) in blocks[self.key][self.index]:
            self.display_arrs[y + self.y][x + self.x] = 1
            self.color_arrs[y + self.y][x + self.x] = self.key
        self.del_full_row()
        self.creat_new_block()

    def del_full_row(self):
        lines = 0
        for row in range(rows):
            if sum(self.display_arrs[row]) == cols:
                lines += 1
                self.lines += 1
                if self.lines % 5 == 0:
                    self.level = self.lines // 5
                    self.speed = int(self.speed * 0.9)
                self.score += (self.level + cols * lines) * 5
                del self.display_arrs[row]
                del self.color_arrs[row]
                self.display_arrs.insert(0, [0 for i in range(cols)])
                self.color_arrs.insert(0, [0 for i in range(cols)])
        if lines > 0:
            if self == player1:
                player2.opponent_rows.extend(self.generate_opponent_rows(lines))
                player2.add_opponent_rows()  # 立即增加对手行
            else:
                player1.opponent_rows.extend(self.generate_opponent_rows(lines))
                player1.add_opponent_rows()  # 立即增加对手行

    def generate_opponent_rows(self, num_rows):
        rows = []
        for _ in range(num_rows):
            row = [random.choice([0, 1]) for _ in range(cols)]
            if sum(row) == 0:
                row[random.randint(0, cols - 1)] = 1
            rows.append(row)
        return rows

    def add_opponent_rows(self):
        while self.opponent_rows:
            new_row = self.opponent_rows.pop(0)
            self.display_arrs.pop(0)
            self.display_arrs.append(new_row)
            self.color_arrs.pop(0)
            self.color_arrs.append([random.randint(1, 7) for _ in range(cols)])
        if self.check_game_over():
            self.game_over()

    def display(self):
        self.display_stop_blocks()
        self.display_next_blocks()
        self.display_move_blocks()
        self.display_score()
        if not self.game_over_flag:
            self.fall_buffer -= 1
            if self.fall_buffer == 0 or self.fall_speed_up:
                self.fall_buffer = self.speed
                self.move(0, 1)
        else:
            self.display_game_over()

    def display_stop_blocks(self):
        for y in range(rows):
            for x in range(cols):
                self.rect.topleft = x * cell_size, y * cell_size
                if self.display_arrs[y][x]:
                    self.draw_block(self.color_arrs[y][x], 1)
                else:
                    self.draw_block(0, 0)

    def display_next_blocks(self):
        for (x, y) in blocks[self.next_key][0]:
            self.rect.topleft = x * cell_size, (y - 1) * cell_size
            self.draw_block(8, 1)

    def display_move_blocks(self):
        for (x, y) in blocks[self.key][self.index]:
            self.rect.topleft = (self.x + x) * cell_size, (self.y + y) * cell_size
            self.draw_block(self.key, 1)

    def display_score(self):
        text = "得分：%d  行数：%d  等级：%d" % (self.score, self.lines, self.level)
        self.img = pygame.font.SysFont("kaiti", 25).render(text, True, (0, 0, 255))
        self.img_rect = self.img.get_rect()
        self.img_rect.topleft = (self.x0, rows * cell_size)
        screen.blit(self.img, self.img_rect)

    def draw_block(self, color_index, draw_edge):
        (r, g, b) = app_colors[color_index]
        self.rect.centerx = self.rect.left + self.x0 + int(cell_size / 2)
        self.rect.centery = self.rect.top + self.y0 + int(cell_size / 2)
        if draw_edge:
            x0 = self.rect.center
            x1 = self.rect.topleft
            x2 = self.rect.topright
            x3 = self.rect.bottomright
            x4 = self.rect.bottomleft
            pygame.draw.polygon(screen, (r + 50, g + 50, b + 50), (x0, x1, x2), 0)
            pygame.draw.polygon(screen, (r + 20, g + 20, b + 20), (x0, x2, x3), 0)
            pygame.draw.polygon(screen, (r - 50, g - 50, b - 50), (x0, x3, x4), 0)
            pygame.draw.polygon(screen, (r - 20, g - 20, b - 20), (x0, x4, x1), 0)
            pygame.draw.rect(screen, (r, g, b), self.rect.inflate(-block_edge, -block_edge), 0)
        else:
            pygame.draw.rect(screen, (r, g, b), self.rect, 0)

    def check_game_over(self):
        for x in range(cols):
            if self.display_arrs[0][x] == 1:
                return True
        return False

    def game_over(self):
        self.game_over_flag = True
        global game_running
        game_running = False

    def display_game_over(self):
        font = pygame.font.SysFont("kaiti", 40)
        if self == player1:
            text = "玩家1失败" if player1.game_over_flag else "玩家1胜利"
        else:
            text = "玩家2失败" if player2.game_over_flag else "玩家2胜利"
        img = font.render(text, True, (255, 0, 0))
        img_rect = img.get_rect(center=(self.x0 + cols * cell_size // 2, win_hight // 2))
        screen.blit(img, img_rect)

def display_restart_button():
    font = pygame.font.SysFont("kaiti", 30)
    text = "重新开始"
    img = font.render(text, True, (0, 0, 255))
    img_rect = img.get_rect(center=(win_width // 2, win_hight - 50))
    screen.blit(img, img_rect)
    return img_rect

def restart_game():
    global player1, player2, game_running
    player1 = Tetris(0, 0)
    player2 = Tetris((cols + 6) * cell_size, 0)
    game_running = True

clock = pygame.time.Clock()
player1 = Tetris(0, 0)
player2 = Tetris((cols + 6) * cell_size, 0)
game_running = True

while True:
    while game_running:
        clock.tick(fps)
        screen.fill((166, 138, 88))
        player1.display()
        player2.display()
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                # 玩家一控制
                if event.key == pygame.K_d:
                    player1.move(1, 0)
                elif event.key == pygame.K_a:
                    player1.move(-1, 0)
                elif event.key == pygame.K_w:
                    player1.rotate()
                elif event.key == pygame.K_s:
                    player1.fall_speed_up = True

                # 玩家二控制
                if event.key == pygame.K_RIGHT:
                    player2.move(1, 0)
                elif event.key == pygame.K_LEFT:
                    player2.move(-1, 0)
                elif event.key == pygame.K_UP:
                    player2.rotate()
                elif event.key == pygame.K_DOWN:
                    player2.fall_speed_up = True
                elif event.key == pygame.K_q:
                    game_running = False

            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_s:
                    player1.fall_speed_up = False
                if event.key == pygame.K_DOWN:
                    player2.fall_speed_up = False
            elif event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

    screen.fill((166, 138, 88))
    player1.display_game_over()
    player2.display_game_over()
    restart_button_rect = display_restart_button()
    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if restart_button_rect.collidepoint(event.pos):
                restart_game()
        elif event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
